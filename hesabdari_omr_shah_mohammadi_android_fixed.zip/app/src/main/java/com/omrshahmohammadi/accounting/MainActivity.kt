package com.omrshahmohammadi.accounting

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class DB(ctx: Context): SQLiteOpenHelper(ctx, "accounting.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,type TEXT,unit TEXT,qty REAL,buy REAL,sell REAL)")
        d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,address TEXT,accountType TEXT,initialDebt REAL)")
        d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT,product TEXT,qty REAL,price REAL,total REAL,paid REAL,type TEXT,date TEXT)")
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT,amount REAL,date TEXT,method TEXT)")
    }
    override fun onUpgrade(d: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
}

class MainActivity : Activity() {
    private lateinit var db: DB
    private lateinit var body: LinearLayout
    private val green = Color.rgb(22,131,75)
    private val dark = Color.rgb(24,53,42)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = DB(this)
        buildShell()
        home()
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(247,250,248)) }
        val head = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(24,22,20,20); setBackgroundColor(green)
        }
        head.addView(tv("حسابداری شرکت زراعتی عمر شاه محمدی",22,Color.WHITE,true))
        head.addView(tv("سم و کود زراعتی • افغانی",13,Color.WHITE,false))
        root.addView(head, LinearLayout.LayoutParams(-1,130))
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,16,16,90) }
        scroll.addView(body); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE); gravity=Gravity.CENTER }
        listOf("خانه","فروش","انبار","مشتریان","گزارش").forEach { n ->
            val x=Button(this).apply { text=n; setTextColor(dark); setBackgroundColor(Color.TRANSPARENT); setOnClickListener {
                when(n){ "خانه"->home(); "فروش"->sales(); "انبار"->inventory(); "مشتریان"->customers(); else->reports() }
            }}
            nav.addView(x, LinearLayout.LayoutParams(0,70,1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun clear(title:String) {
        body.removeAllViews()
        body.addView(tv(title,20,dark,true))
        space(8)
    }
    private fun tv(s:String,size:Int,color:Int,bold:Boolean=false)=TextView(this).apply {
        text=s; textSize=size.toFloat(); setTextColor(color); if(bold) setTypeface(null,1); setPadding(4,5,4,5)
    }
    private fun field(hint:String, inputType:Int=1):EditText=EditText(this).apply { this.hint=hint; this.inputType=inputType; setPadding(12,8,12,8); setBackgroundColor(Color.WHITE) }
    private fun button(s:String, action:()->Unit):Button=Button(this).apply { text=s; setOnClickListener{action()} }
    private fun space(h:Int){ body.addView(Space(this),LinearLayout.LayoutParams(1,h)) }
    private fun card(v:android.view.View){ val box=LinearLayout(this).apply{setPadding(12,8,12,8);setBackgroundColor(Color.WHITE)};box.addView(v);body.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,10)}) }
    private fun money(x:Double)=String.format(Locale.US,"%,.0f افغانی",x)

    private fun home(){
        clear("داشبورد")
        val c=db.readableDatabase
        var sales=0.0; var debt=0.0
        c.rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(total-paid),0) FROM sales",null).use{if(it.moveToFirst()){sales=it.getDouble(0);debt=it.getDouble(1)}}
        card(tv("💰 فروش کل\n${money(sales)}",18,dark,true))
        card(tv("🔴 طلب مشتریان\n${money(debt)}",18,Color.rgb(170,40,40),true))
        card(tv("📦 تعداد کالا: ${count("products")}     👥 مشتریان: ${count("customers")}",16,dark,true))
        button("＋ ثبت فروش"){sales()}.also{body.addView(it)}
        button("＋ ثبت کالا"){newProduct()}.also{body.addView(it)}
        button("＋ ثبت مشتری"){newCustomer()}.also{body.addView(it)}
    }
    private fun count(t:String):Int { db.readableDatabase.rawQuery("SELECT COUNT(*) FROM $t",null).use{it.moveToFirst();return it.getInt(0)} }

    private fun sales(){
        clear("ثبت فروش")
        val customer=Spinner(this); val names=mutableListOf("مشتری نقدی")
        db.readableDatabase.rawQuery("SELECT name FROM customers ORDER BY name",null).use{while(it.moveToNext())names.add(it.getString(0))}
        customer.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names); body.addView(tv("مشتری",13,dark));body.addView(customer)
        val product=Spinner(this); val prods=mutableListOf<String>(); val ids=mutableListOf<Long>()
        db.readableDatabase.rawQuery("SELECT id,name FROM products ORDER BY name",null).use{while(it.moveToNext()){ids.add(it.getLong(0));prods.add(it.getString(1))}}
        product.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,if(prods.isEmpty()) mutableListOf("ابتدا کالا ثبت کنید") else prods)
        body.addView(tv("محصول",13,dark));body.addView(product)
        val qty=field("تعداد"); val price=field("قیمت فروش واحد"); val paid=field("مبلغ پرداختی")
        qty.inputType=2;price.inputType=2;paid.inputType=2
        body.addView(qty);body.addView(price);body.addView(paid)
        val type=Spinner(this); type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("نقدی","قرضی"));body.addView(type)
        val save=button("ثبت فروش"){ 
            if(prods.isEmpty()){toast("کالا ثبت نشده است");return@button}
            val q=qty.text.toString().toDoubleOrNull()?:0.0; val p=price.text.toString().toDoubleOrNull()?:0.0
            val total=q*p; val pay=if(type.selectedItemPosition==0) total else paid.text.toString().toDoubleOrNull()?:0.0
            if(q<=0||p<=0){toast("تعداد و قیمت را وارد کنید");return@button}
            val d=db.writableDatabase; d.execSQL("INSERT INTO sales(customer,product,qty,price,total,paid,type,date) VALUES(?,?,?,?,?,?,?,?)",
                arrayOf(customer.selectedItem.toString(),product.selectedItem.toString(),q,p,total,pay,type.selectedItem.toString(),today()))
            d.execSQL("UPDATE products SET qty=MAX(0,qty-?) WHERE id=? ",arrayOf(q,ids[product.selectedItemPosition]))
            toast("فروش ثبت شد"); home()
        };body.addView(save)
    }

    private fun inventory(){
        clear("انبار سم و کود")
        button("＋ ثبت کالای جدید"){newProduct()}.also{body.addView(it)}
        db.readableDatabase.rawQuery("SELECT name,type,unit,qty,buy,sell FROM products ORDER BY name",null).use{
            if(!it.moveToFirst()){body.addView(tv("هنوز کالایی ثبت نشده است.",15,Color.GRAY,false))}
            else do { val s="${it.getString(0)}\n${it.getString(1)} • ${it.getDouble(3)} ${it.getString(2)}\nخرید: ${money(it.getDouble(4))} | فروش: ${money(it.getDouble(5))}";card(tv(s,15,dark,false)) } while(it.moveToNext())
        }
    }
    private fun newProduct(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,10,20,5)}
        val n=field("نام محصول"); val type=field("نوع: سم یا کود");val unit=field("واحد: بوتل، کیلو، بوجی...");val qty=field("موجودی اولیه");val buy=field("قیمت خرید واحد");val sell=field("قیمت فروش واحد")
        listOf(n,type,unit,qty,buy,sell).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("ثبت کالای جدید").setView(box).setPositiveButton("ثبت"){_,_->db.writableDatabase.execSQL("INSERT INTO products(name,type,unit,qty,buy,sell) VALUES(?,?,?,?,?,?)",arrayOf(n.text.toString(),type.text.toString(),unit.text.toString(),qty.text.toString().toDoubleOrNull()?:0.0,buy.text.toString().toDoubleOrNull()?:0.0,sell.text.toString().toDoubleOrNull()?:0.0));inventory()}.setNegativeButton("لغو",null).show()
    }

    private fun customers(){
        clear("مشتریان و حساب‌های قرضی")
        button("＋ ثبت مشتری جدید"){newCustomer()}.also{body.addView(it)}
        db.readableDatabase.rawQuery("SELECT name,phone,address FROM customers ORDER BY name",null).use{
            if(!it.moveToFirst()) body.addView(tv("هنوز مشتری ثبت نشده است.",15,Color.GRAY,false))
            else do {card(tv("${it.getString(0)}\n${it.getString(1)}\n${it.getString(2)}",15,dark,false))}while(it.moveToNext())
        }
    }
    private fun newCustomer(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,10,20,5)}
        val n=field("نام مشتری");val phone=field("شماره تماس");val addr=field("آدرس");val type=field("نوع حساب: نقدی یا قرضی");val debt=field("مبلغ اولیه بدهی")
        listOf(n,phone,addr,type,debt).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("ثبت مشتری جدید").setView(box).setPositiveButton("ثبت"){_,_->db.writableDatabase.execSQL("INSERT INTO customers(name,phone,address,accountType,initialDebt) VALUES(?,?,?,?,?)",arrayOf(n.text.toString(),phone.text.toString(),addr.text.toString(),type.text.toString(),debt.text.toString().toDoubleOrNull()?:0.0));customers()}.setNegativeButton("لغو",null).show()
    }

    private fun reports(){
        clear("گزارش سود و زیان")
        var sales=0.0;var cost=0.0
        db.readableDatabase.rawQuery("SELECT product,qty,total FROM sales",null).use{while(it.moveToNext()){sales+=it.getDouble(2);db.rawQuery("SELECT buy FROM products WHERE name=?",arrayOf(it.getString(0))).use{p->if(p.moveToFirst())cost+=p.getDouble(0)*it.getDouble(1)}}}
        card(tv("مجموع فروش\n${money(sales)}",18,dark,true));card(tv("بهای کالاهای فروخته‌شده\n${money(cost)}",18,dark,true));card(tv("سود ناخالص\n${money(sales-cost)}",20,green,true))
    }
    private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
